package br.com.fiap.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.fiap.to.AcessibilidadeTO;

public class AcessibilidadeDAO {

	private static List<AcessibilidadeTO> listaAcessibilidades;

	public AcessibilidadeDAO() {
		if (listaAcessibilidades == null) {

			// CODIFICAÇÃO DO BANCO DE DADOS >> UM SELECT >> TO TIPO LIST
			// SELECT

			listaAcessibilidades = new ArrayList<AcessibilidadeTO>();

			AcessibilidadeTO pto = new AcessibilidadeTO();
			pto.setCodigo(1);
			pto.setTipoAcessibilidade("Pronatomalia");
			pto.setdescricaoAcessibilidade(
					"Nesse tipo de daltonismo, a pessoa tem dificuldade em distinguir cores no espectro vermelho. As cores parecem desbotadas e semelhantes umas às outras. "
					+ "Os tons de vermelho, laranja e amarelo podem ser especialmente desafiadores de diferenciar.");
			listaAcessibilidades.add(pto);

			pto = new AcessibilidadeTO();
			pto.setCodigo(2);
			pto.setTipoAcessibilidade("Deuteranomalia");
			pto.setdescricaoAcessibilidade("Esse tipo de daltonismo afeta a percepção das cores no espectro verde. As cores verdes e vermelhas podem parecer muito semelhantes, e a "
					+ "pessoa pode ter dificuldade em distinguir entre elas. Isso pode afetar a capacidade de discernir tons sutis de verde e vermelho.");
			listaAcessibilidades.add(pto);

			pto = new AcessibilidadeTO();
			pto.setCodigo(3);
			pto.setTipoAcessibilidade("Tritanomálico");
			pto.setdescricaoAcessibilidade("O daltonismo tritanomálico é menos comum do que os dois tipos mencionados anteriormente. Nesse tipo, a pessoa tem dificuldade em perceber cores no espectro azul-amarelo. "
					+ "Os tons de azul podem parecer esverdeados e os tons de amarelo podem parecer rosados ou acinzentados.");
			listaAcessibilidades.add(pto);

			pto = new AcessibilidadeTO();
			pto.setCodigo(4);
			pto.setTipoAcessibilidade("Protanopia");
			pto.setdescricaoAcessibilidade("A protanopia é um tipo mais raro de daltonismo em que a pessoa não é capaz de perceber o espectro vermelho. "
					+ "Isso significa que as cores que contêm vermelho, como laranja, vermelho e rosa, podem parecer muito diferentes ou até mesmo inexistentes. Os tons de verde podem parecer acinzentados.");
			listaAcessibilidades.add(pto);

			pto = new AcessibilidadeTO();
			pto.setCodigo(5);
			pto.setTipoAcessibilidade("Deuteranopia");
			pto.setdescricaoAcessibilidade("A deuteranopia é semelhante à protanopia, mas afeta a percepção das cores verdes. A pessoa não é capaz de ver o espectro verde adequadamente, tornando difícil distinguir entre verde e vermelho. "
					+ "As cores que contêm verde, como verde claro e verde escuro, podem parecer diferentes ou incolor para pessoas com deuteranopia.");
			listaAcessibilidades.add(pto);

		}
	}

	// SELECT ALL
	public List<AcessibilidadeTO> select() {
		return listaAcessibilidades;
	}

	// SELECT BY_ID
	public AcessibilidadeTO select(int id) {
		for (int i = 0; i < listaAcessibilidades.size(); i++) {
			if (listaAcessibilidades.get(i).getCodigo() == id) {
				return listaAcessibilidades.get(i);
			}
		}
		return null;
	}

	// INSERT
	public boolean insert(AcessibilidadeTO pto) {
		pto.setCodigo(listaAcessibilidades.size() + 1);
		return listaAcessibilidades.add(pto);
	}

	// UPDATE
	public void update(AcessibilidadeTO pto) {
		AcessibilidadeTO p = select(pto.getCodigo());
		p.setTipoAcessibilidade(null);
		p.setdescricaoAcessibilidade(null);
	}

	// DELETE
	public void delete(int id) {
		listaAcessibilidades.remove(select(id));
	}

}
