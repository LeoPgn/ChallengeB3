package br.com.fiap.to;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AcessibilidadeTO {

	private int codigo;
	private String tipoAcessibilidade;
	private String descricaoAcessibilidade;
	
	public AcessibilidadeTO() {
		// TODO Auto-generated constructor stub
	}
		
	public AcessibilidadeTO(int codigo, String tipoAcessibilidade, String descricaoAcessibilidade) {
		super();
		this.codigo = codigo;
		this.tipoAcessibilidade = tipoAcessibilidade;
		this.descricaoAcessibilidade = descricaoAcessibilidade;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getTipoAcessbilidade() {
		return tipoAcessibilidade;
	}

	public void setTipoAcessibilidade(String tipoAcessibilidade) {
		this.tipoAcessibilidade = tipoAcessibilidade;
	}

	public String getDescricaoAcessibilidade() {
		return descricaoAcessibilidade;
	}

	public void setdescricaoAcessibilidade(String descricaoAcessibilidade) {
		this.descricaoAcessibilidade = descricaoAcessibilidade;
	}
	
}
