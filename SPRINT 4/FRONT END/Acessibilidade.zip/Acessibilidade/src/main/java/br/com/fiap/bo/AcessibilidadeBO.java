package br.com.fiap.bo;

import java.util.List;

import br.com.fiap.dao.AcessibilidadeDAO;
import br.com.fiap.to.AcessibilidadeTO;

public class AcessibilidadeBO {

	private AcessibilidadeDAO pd;

	public List<AcessibilidadeTO> listar() {
		pd = new AcessibilidadeDAO();
		// REGRAS DE NEGÓCIO
		return pd.select();
	}

	public AcessibilidadeTO listar(int id) {
		pd = new AcessibilidadeDAO();
		// REGRAS DE NEGÓCIO
		return pd.select(id);
	}

	public boolean cadastrar(AcessibilidadeTO pto) {
		pd = new AcessibilidadeDAO();
		// REGRAS DE NEGÓCIO
		return pd.insert(pto);
	}

	public void atualiza(AcessibilidadeTO pto) {
		pd = new AcessibilidadeDAO();
		// REGRAS DE NEGÓCIO
		pd.update(pto);
	}

	public void remover(int id) {
		pd = new AcessibilidadeDAO();
		// REGRAS DE NEGÓCIO
		pd.delete(id);
	}

}
