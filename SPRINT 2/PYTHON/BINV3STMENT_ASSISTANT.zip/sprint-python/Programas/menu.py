menu = 0

while menu == 0:
    print("1 - Gerenciar minha conta \n2 - Gerenciar meus investimentos \n3 - Gerenciar meus cursos \n4 - Sair")
    opt = int(input("Digite a opção desejada: "))
    if opt == 1:
        print("1 - Alterar minha senha \n2 - Alterar meu e-mail \n3 - Alterar meu telefone de contato")
        input("Aperte ENTER para continuar: ")
    elif opt == 2:
        print("1 - Acessar os meus investimentos \n2 - Acessar minhas indicações de investimentos \n3 - Acessar meu histórico de compras de ações")
        input("Aperte ENTER para continuar: ")
    elif opt == 3:
        print("1 - Acessar meu histórico de cursos \n2 - Acessar meus cursos em andamento")
        input("Aperte ENTER para continuar: ")
    elif opt == 4:
        menu = int(input("Deseja sair do programa? (0 - NÃO / 1 - SIM)\n"))
   
